import 'package:flutter/material.dart';

void main() => runApp(ExemploInicial(title: "Crivo de Eratóstenes"));

class ExemploInicial extends StatefulWidget {
  final String title;
  const ExemploInicial({Key? key, required this.title}) : super(key: key);
  @override
  _ExemploInicial createState() => _ExemploInicial();
}

class _ExemploInicial extends State<ExemploInicial> {
  var _currentPage = 0;
  final TextEditingController _numberController = TextEditingController();
  int? _valorGlobal;

  @override
  Widget build(BuildContext context) {
    final List<Widget> _pages = [
      Home(
        onSave: (value) {
          setState(() {
            _valorGlobal = int.parse(value);
          });
        },
        numberController: _numberController,
      ),
      Valores(valorGlobal: _valorGlobal),
    ];

    return MaterialApp(
      home: Scaffold(
        body: Center(
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 500),
            transitionBuilder: (Widget child, Animation<double> animation) {
              return SlideTransition(
                position: Tween<Offset>(
                  begin: const Offset(1.0, 0.0),
                  end: Offset.zero,
                ).animate(animation),
                child: child,
              );
            },
            child: _pages.elementAt(_currentPage),
          ),
        ),
        bottomNavigationBar: BottomNavigationBar(
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.home), label: "Início"),
            BottomNavigationBarItem(
                icon: Icon(Icons.bar_chart), label: "Valores"),
          ],
          currentIndex: _currentPage,
          fixedColor: Colors.blueAccent,
          onTap: (int inIndex) {
            setState(() {
              _currentPage = inIndex;
            });
          },
        ),
      ),
    );
  }
}

class Home extends StatelessWidget {
  final Function(String) onSave;
  final TextEditingController numberController;

  const Home({Key? key, required this.onSave, required this.numberController})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          TextField(
            controller: numberController,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(
              labelText: "Digite um número",
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              focusedBorder: OutlineInputBorder(
                borderSide: BorderSide(color: Colors.blueAccent),
                borderRadius: BorderRadius.circular(12),
              ),
              filled: true,
              fillColor: Colors.blue.shade50,
            ),
          ),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: () {
              if (numberController.text.isNotEmpty) {
                onSave(numberController.text);
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blueAccent,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            child: const Text(
              "Aplicar Crivo",
              style: TextStyle(fontSize: 16, color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }
}

class Valores extends StatelessWidget {
  final int? valorGlobal;

  const Valores({Key? key, required this.valorGlobal}) : super(key: key);

  List<int> _crivoDeEratostenes(int n) {
    if (n < 2) {
      return [];
    }
    List<bool> valores = List.filled(n + 1, true);
    valores[0] = false;
    valores[1] = false;
    for (int i = 2; i * i <= n; i++) {
      if (valores[i]) {
        for (int j = i * i; j <= n; j += i) {
          valores[j] = false;
        }
      }
    }
    List<int> primos = [];
    for (int i = 2; i <= n; i++) {
      if (valores[i]) {
        primos.add(i);
      }
    }
    return primos;
  }

  @override
  Widget build(BuildContext context) {
    List<int> primos =
        valorGlobal != null ? _crivoDeEratostenes(valorGlobal!) : [];
    return Center(
      child: Text(
        primos.isNotEmpty ? primos.join(', ') : 'Nenhum número primo',
        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
      ),
    );
  }
}
